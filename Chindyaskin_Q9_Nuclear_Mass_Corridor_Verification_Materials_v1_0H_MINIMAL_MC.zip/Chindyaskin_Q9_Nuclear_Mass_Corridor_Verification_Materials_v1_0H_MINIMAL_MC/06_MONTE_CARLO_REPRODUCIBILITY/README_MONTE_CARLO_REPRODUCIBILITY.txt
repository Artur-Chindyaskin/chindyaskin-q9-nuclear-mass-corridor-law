# Monte Carlo Reproducibility Files

This folder contains the minimal files needed to reproduce the v1.0C random-control layer.

Run:

python run_q9_monte_carlo_controls_v1_0C.py

Fast test:

python run_q9_monte_carlo_controls_v1_0C.py --trials 1000

Default settings:

trials = 100000
seed = 20260627

Inputs are in ./inputs.
Expected article outputs are in ./expected_outputs.
New outputs are written to ./recomputed_outputs.
