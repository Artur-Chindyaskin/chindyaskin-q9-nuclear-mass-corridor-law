#!/usr/bin/env python3
"""
Reproduce the v1.0C Monte Carlo and sliding-window controls for the
Chindyaskin Q9 Nuclear-Mass Corridor Law.

Run from this folder:
    python run_q9_monte_carlo_controls_v1_0C.py

Fast test:
    python run_q9_monte_carlo_controls_v1_0C.py --trials 1000

Inputs are read from ./inputs.
Outputs are written to ./recomputed_outputs.
"""
from pathlib import Path
import argparse, json
import numpy as np
import pandas as pd

TARGETS = np.arange(12, 23)
DEFAULT_TRIALS = 100_000
DEFAULT_SEED = 20260627

def longest_run_bool(arr):
    best = cur = 0
    for x in arr:
        if bool(x):
            cur += 1
            best = max(best, cur)
        else:
            cur = 0
    return best

def summarize_batch_dists(dists):
    tight_counts = (dists <= 0.025).sum(axis=1)
    good_counts = (dists <= 0.05).sum(axis=1)
    corridor_counts = (dists <= 0.10).sum(axis=1)
    means = dists.mean(axis=1)
    maxs = dists.max(axis=1)
    longest = np.array([longest_run_bool(row) for row in (dists <= 0.025)])
    return tight_counts, good_counts, corridor_counts, means, maxs, longest

def run_control_uniform(rng, label, k, lo, hi, obs, trials, batch=2000):
    agg = {key: 0 for key in ['tight_ge','good_ge','corridor_ge','all_targets_tight','mean_le','max_le','both_mean_max','longest_ge']}
    sum_tight = 0
    sum_longest = 0
    hist_tight = np.zeros(12, dtype=int)
    hist_longest = np.zeros(12, dtype=int)
    for done in range(0, trials, batch):
        b = min(batch, trials - done)
        vals = rng.uniform(lo, hi, size=(b, k))
        dists = np.min(np.abs(vals[:, :, None] - TARGETS[None, None, :]), axis=1)
        t, g, c, mean, maxv, longest = summarize_batch_dists(dists)
        agg['tight_ge'] += int((t >= obs['tight']).sum())
        agg['good_ge'] += int((g >= obs['good']).sum())
        agg['corridor_ge'] += int((c >= obs['corridor']).sum())
        agg['all_targets_tight'] += int((t == len(TARGETS)).sum())
        agg['mean_le'] += int((mean <= obs['mean']).sum())
        agg['max_le'] += int((maxv <= obs['max']).sum())
        agg['both_mean_max'] += int(((mean <= obs['mean']) & (maxv <= obs['max'])).sum())
        agg['longest_ge'] += int((longest >= obs['longest']).sum())
        sum_tight += int(t.sum())
        sum_longest += int(longest.sum())
        hist_tight += np.bincount(t, minlength=12)[:12]
        hist_longest += np.bincount(longest, minlength=12)[:12]
    out = make_summary(label, trials, k, f'uniform_N_range_{lo:.6f}_to_{hi:.6f}', obs, agg, sum_tight, sum_longest)
    return out, hist_tight, hist_longest

def run_control_sample(rng, label, pop, k, obs, trials, batch=2000):
    pop = np.asarray(pop, dtype=float)
    pop = pop[np.isfinite(pop)]
    n = len(pop)
    agg = {key: 0 for key in ['tight_ge','good_ge','corridor_ge','all_targets_tight','mean_le','max_le','both_mean_max','longest_ge']}
    sum_tight = 0
    sum_longest = 0
    hist_tight = np.zeros(12, dtype=int)
    hist_longest = np.zeros(12, dtype=int)
    for done in range(0, trials, batch):
        b = min(batch, trials - done)
        idx = rng.integers(0, n, size=(b, k))
        vals = pop[idx]
        dists = np.min(np.abs(vals[:, :, None] - TARGETS[None, None, :]), axis=1)
        t, g, c, mean, maxv, longest = summarize_batch_dists(dists)
        agg['tight_ge'] += int((t >= obs['tight']).sum())
        agg['good_ge'] += int((g >= obs['good']).sum())
        agg['corridor_ge'] += int((c >= obs['corridor']).sum())
        agg['all_targets_tight'] += int((t == len(TARGETS)).sum())
        agg['mean_le'] += int((mean <= obs['mean']).sum())
        agg['max_le'] += int((maxv <= obs['max']).sum())
        agg['both_mean_max'] += int(((mean <= obs['mean']) & (maxv <= obs['max'])).sum())
        agg['longest_ge'] += int((longest >= obs['longest']).sum())
        sum_tight += int(t.sum())
        sum_longest += int(longest.sum())
        hist_tight += np.bincount(t, minlength=12)[:12]
        hist_longest += np.bincount(longest, minlength=12)[:12]
    out = make_summary(label, trials, k, f'{label}_population_size_{n}', obs, agg, sum_tight, sum_longest)
    return out, hist_tight, hist_longest

def make_summary(label, trials, k, pop_desc, obs, agg, sum_tight, sum_longest):
    return {
        'control': label,
        'trials': trials,
        'sample_size_per_trial': k,
        'population_or_range': pop_desc,
        'observed_tight_nodes': obs['tight'],
        'observed_good_nodes': obs['good'],
        'observed_corridor_nodes': obs['corridor'],
        'observed_mean_abs_residual': obs['mean'],
        'observed_max_abs_residual': obs['max'],
        'observed_longest_tight_run': obs['longest'],
        'p_tight_count_ge_observed': agg['tight_ge'] / trials,
        'p_all_targets_tight': agg['all_targets_tight'] / trials,
        'p_mean_le_observed': agg['mean_le'] / trials,
        'p_max_le_observed': agg['max_le'] / trials,
        'p_both_mean_and_max_le_observed': agg['both_mean_max'] / trials,
        'p_longest_tight_run_ge_observed': agg['longest_ge'] / trials,
        'random_mean_tight_count': sum_tight / trials,
        'random_mean_longest_tight_run': sum_longest / trials,
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--trials', type=int, default=DEFAULT_TRIALS)
    ap.add_argument('--seed', type=int, default=DEFAULT_SEED)
    args = ap.parse_args()
    here = Path(__file__).resolve().parent
    inp = here / 'inputs'
    outdir = here / 'recomputed_outputs'
    outdir.mkdir(exist_ok=True)

    full = pd.read_csv(inp / '03_q9_AME_NUBASE_full_groundstate_audit_v1_0B.csv')
    ladder = pd.read_csv(inp / '07_AME_NUBASE_natural_proof_ladder_N12_22_v1_0B.csv')
    n23 = pd.read_csv(inp / '08_N23_role_separation_AME_NUBASE_v1_0B.csv')
    quality = pd.read_csv(inp / '10_data_quality_summary_AME_NUBASE_v1_0B.csv')

    obs_d = ladder['AME_NUBASE_abs_residual_N'].to_numpy()
    obs = {
        'tight': int((obs_d <= 0.025).sum()),
        'good': int((obs_d <= 0.05).sum()),
        'corridor': int((obs_d <= 0.10).sum()),
        'mean': float(obs_d.mean()),
        'max': float(obs_d.max()),
        'longest': 11,
    }
    rng = np.random.default_rng(args.seed)
    q0 = full[full['q_data_layer_AME_NUBASE'] == 'Q0_natural_abundance_measured'].copy()
    q0_q = q0['q9_N_nuc'].dropna().to_numpy()
    q_all = full['q9_N_nuc'].dropna().to_numpy()
    q_q0q1 = full[full['q_data_layer_AME_NUBASE'].isin(['Q0_natural_abundance_measured','Q1_known_measured_or_evaluated'])]['q9_N_nuc'].dropna().to_numpy()

    control_rows = []
    hist_rows = []
    for runner, label, pop in [
        ('uniform', 'A_uniform_random_N_positions_same_count_as_Q0_natural_AME_NUBASE', None),
        ('sample', 'B_shuffle_Q0_natural_flags_among_all_AME_NUBASE_ground_states', q_all),
        ('sample', 'C_shuffle_Q0_natural_flags_within_Q0_Q1_measured_no_hash_population', q_q0q1),
    ]:
        if runner == 'uniform':
            res, h1, h2 = run_control_uniform(rng, label, len(q0_q), float(q0_q.min()), float(q0_q.max()), obs, args.trials)
        else:
            res, h1, h2 = run_control_sample(rng, label, pop, len(q0_q), obs, args.trials)
        control_rows.append(res)
        for i, cnt in enumerate(h1):
            hist_rows.append({'control': label, 'hist_type': 'tight_count', 'value': i, 'count': int(cnt)})
        for i, cnt in enumerate(h2):
            hist_rows.append({'control': label, 'hist_type': 'longest_tight_run', 'value': i, 'count': int(cnt)})

    control_df = pd.DataFrame(control_rows)
    control_df.to_csv(outdir / 'recomputed_random_control_summary.csv', index=False)
    pd.DataFrame(hist_rows).to_csv(outdir / 'recomputed_random_control_histograms.csv', index=False)

    slide_rows = []
    for start in range(0, 13):
        ts = np.arange(start, start + 11)
        d = np.array([np.min(np.abs(q0_q - t)) for t in ts])
        best_nuclides = []
        for t in ts:
            idx = (np.abs(q0['q9_N_nuc'].to_numpy() - t)).argmin()
            best_nuclides.append(q0.iloc[idx]['nuclide'])
        slide_rows.append({
            'window_start_N': start,
            'window_end_N': start + 10,
            'tight_nodes': int((d <= 0.025).sum()),
            'good_nodes': int((d <= 0.05).sum()),
            'corridor_nodes': int((d <= 0.10).sum()),
            'mean_abs_residual': float(d.mean()),
            'max_abs_residual': float(d.max()),
            'best_anchor_chain': ' → '.join(best_nuclides),
            'is_observed_proof_window_N12_22': start == 12,
        })
    slide_df = pd.DataFrame(slide_rows)
    slide_df.to_csv(outdir / 'recomputed_sliding_window_control.csv', index=False)

    summary = {
        'trials': args.trials,
        'seed': args.seed,
        'observed': obs,
        'random_control_summary': control_rows,
        'best_sliding_window': slide_df.sort_values(['tight_nodes','mean_abs_residual'], ascending=[False, True]).iloc[0].to_dict(),
    }
    (outdir / 'recomputed_summary_metrics.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Wrote outputs to', outdir)
    print(control_df.to_string(index=False))
    print('Best sliding window:')
    print(slide_df.sort_values(['tight_nodes','mean_abs_residual'], ascending=[False, True]).head(3).to_string(index=False))

if __name__ == '__main__':
    main()
