Chindyaskin Q9 Nuclear-Mass Corridor Law — Verification Materials v1.0H MINIMAL

Author: Artur Chindyaskin
Framework: Interlayer Circulation Model (ICM)
Package purpose: strict minimum public verification materials for the article.

This ZIP is intended for GitHub publication as supporting verification material.
It does NOT contain the full article text.
It does NOT contain the cover image / Figure 0.
It does NOT contain development drafts, handoff files, old ZIP archives, source DOCX files, or full internal project history.

Contents:

01_FIGURES
- Figure_1_Natural_Ladder_Residuals.png
- Figure_2_Sliding_Window_Control.png
These are the scientific figures used for verification in the article.
Figure 0 / cover image is intentionally excluded.

02_TABLES_AS_IMAGES
- 12 PNG table images used in the article.

03_TABLES_TEXT_COPY
- Plain-text copies of the same 12 article tables.

04_FINAL_TABLES_CSV
- Clean machine-readable CSV versions of the 12 final article tables.
- File names match the article table numbers.

05_MANIFEST
- SHA-256 manifest and file-count summary for this ZIP.

Source data used by the audit:

NIST Atomic Weights and Isotopic Compositions for All Elements:
https://physics.nist.gov/cgi-bin/Compositions/stand_alone.pl?all=all&ascii=ascii&ele=&isotype=all

AME2020 atomic mass evaluation, mass_1.mas20.txt:
https://www-nds.iaea.org/amdc/ame2020/mass_1.mas20.txt

NUBASE2020 nuclear-property evaluation, nubase_4.mas20.txt:
https://www-nds.iaea.org/amdc/ame2020/nubase_4.mas20.txt

Supporting AME/NUBASE documentation:

AMDC / IAEA Atomic Mass Data Center:
https://www-nds.iaea.org/amdc/

AME2020 Part I:
https://www-nds.iaea.org/amdc/ame2020/AME2020-a.pdf

AME2020 Part II:
https://amdc.impcas.ac.cn/masstables/Ame2020/Wang_2021_Chinese_Phys._C_45_030003.pdf

NUBASE2020 publication:
https://www-nds.iaea.org/amdc/ame2020/NUBASE2020.pdf

Rights:
This package is not open source.
No commercial license is granted.
All rights and restrictions are stated in LICENSE.txt.


MONTE CARLO REPRODUCIBILITY

The folder 06_MONTE_CARLO_REPRODUCIBILITY contains the standalone Python runner, required input CSV files, and expected output CSV/JSON files for the v1.0C random-control layer.
